---
title: "Retrato, elogio al duelo"
anio: 2025
temporadas: []
genero:
  - "Teatro"
autor: "Rodrigo Martini"
elenco:
  - "Jessica Becker"
vestuario: "Pepe Uría"
iluminacion: "Ricardo Sica"
musica: ""
sonido: ""
direccion_de_arte: ""
escenografia: ""
fotografia: "Sheila Becker, Horacio López Zeballos"
asistencia_de_direccion: "Nicolás Moreno, Ana Laura Pace"
docente: ""
direccion: "Susana Toscano"
fotos: []
tipo: "obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---

Un unipersonal que intenta interrogarse sobre el mundo de la escena y los padecimientos de sus protagonistas.
Rita Bergman ha sido una gran actriz pero su tiempo pasó, aunque lo intenta no sabe cómo continuar sin el reconocimiento del público, de sus colegas y de ese mundo deslumbrante y cruel de las alfombras rojas.
El sufrimiento se ha trasmutado en abuso de alcohol y una crisis la ha llevado a saltar del escenario en plena función y a atacar con un par de tijeras al público. Tras el escándalo ahora vuelve a la actuación.
Su hermana abogada intentará rescatarla del proceso judicial que la involucra y Cora, una asistente todo terreno, tratará de evitar un final que -a pesar de todos sus esfuerzos- se avizora trágico.
