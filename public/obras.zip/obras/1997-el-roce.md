---
title: "El Roce"
anio: 1997
temporadas: []
genero: ["Teatro"]
autor: "Diego Rafecas, El Roce"
elenco:
  - "Fabián Bril"
  - "Rafael Ferro"
  - "Diego Rafecas"
vestuario: "Paz Rocco, Cecilia Allasia"
iluminacion: "Marcelo Cuervo"
musica: ""
sonido: ""
direccion_de_arte: ""
escenografia: ""
fotografia: "Paz Rocco, Alejandro Gullot"
asistencia_de_direccion: ""
docente: ""
direccion: "El Roce"
fotos:
  - src: "/img/obras/1997-el-roce/1997-el-roce-01.jpg"
    alt: "El Roce, 1997"
    orientacion: vertical
tipo: "Obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---


