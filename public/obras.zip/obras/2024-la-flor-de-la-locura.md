---
title: "La Flor de la Locura"
anio: 2024
temporadas: []
genero:
  - "Teatro"
autor: ""
elenco:
  - "Maria Nydia Ursi-Ducó"
vestuario: "Marcelo Valiente"
iluminacion: "Alejandro Le Roux"
musica: "Gustavo Alvarez Ghibaudi"
sonido: ""
direccion_de_arte: ""
escenografia: "Marcelo Valiente"
fotografia: "Ana María Ferrari"
asistencia_de_direccion: "Lucas Soriano"
docente: ""
direccion: "Mónica Santibañez"
fotos: []
tipo: "obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---

Blanche, internada en un hospital de salud mental intenta convencer a su psiquiatra que no realice una práctica invasiva en su cerebro, una intervención que amenaza con quitarle todo lo que es…lo que fue.

Ella se enfrentará con sus fantasmas y sus eternos miedos. Entraremos en su mundo y viviremos su profunda necesidad de Amor. ¿Es esto locura?
