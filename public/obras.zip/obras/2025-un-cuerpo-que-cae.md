---
title: "Un cuerpo que cae"
anio: 2025
temporadas: []
genero:
  - "Teatro"
autor: ""
elenco:
  - "Silvia Rodriguez"
  - "Cristina Rodríguez"
  - "Ana Sosa"
  - "Miriam Varela"
vestuario: ""
iluminacion: "Paula Fraga"
musica: ""
sonido: "Moreno Curubeto"
direccion_de_arte: ""
escenografia: ""
fotografia: "Jonatan Olmedo"
asistencia_de_direccion: "Eva Iglesias"
docente: ""
direccion: "Gaby Blanco"
fotos: 
  - src: "/img/obras/2025-un-cuerpo-que-cae/2025-un-cuerpo-que-cae-01.jpg"
    alt: "Un cuerpo que cae, 2025"
    orientacion: vertical
tipo: "obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---
