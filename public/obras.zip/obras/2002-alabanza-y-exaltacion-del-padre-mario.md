---
title: "Alabanza y exaltación del Padre Mario"
anio: 2002
temporadas: []
genero: ["Teatro"]
autor: "Néstor Perlongher"
elenco: []
vestuario: ""
iluminacion: ""
musica: ""
sonido: ""
direccion_de_arte: ""
escenografia: ""
fotografia: ""
asistencia_de_direccion: ""
docente: ""
direccion: "Cristina Banegas"
fotos: []
tipo: "Obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---


