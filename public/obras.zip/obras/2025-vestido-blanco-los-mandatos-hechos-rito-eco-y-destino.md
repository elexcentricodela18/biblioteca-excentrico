---
title: "Vestido Blanco. Los mandatos hechos rito, eco y destino"
anio: 2025
temporadas: []
genero:
  - "Teatro"
autor: ""
elenco:
  - "Nahuel Ayuse"
  - "Teresita Velázquez"
vestuario: "Evelin Patricia Alvarez Salazar"
iluminacion: "Karla Torres"
musica: ""
sonido: ""
direccion_de_arte: ""
escenografia: ""
fotografia: "Sofia Etchart"
asistencia_de_direccion: ""
docente: ""
direccion: "Karla Torres"
fotos: 
  - src: "/img/obras/2025-vestido-blanco-los-mandatos-hechos-rito-eco-y-destino/2025-vestido-blanco-los-mandatos-hechos-rito-eco-y-destino-01.jpg"
    alt: "Vestido Blanco. Los mandatos hechos rito, eco y destino, 2025"
    orientacion: vertical
tipo: "obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---
