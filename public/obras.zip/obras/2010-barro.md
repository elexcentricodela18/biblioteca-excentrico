---
title: "Barro"
anio: 2010
temporadas: []
genero: ["Teatro"]
autor: ""
elenco:
  - "Felipe Braga"
  - "Juan Manuel Correa"
  - "Damián Alexis Moroni"
vestuario: "Magda Banach"
iluminacion: ""
musica: "Patricia Miranda Nardelli"
sonido: ""
direccion_de_arte: ""
escenografia: "Magda Banach"
fotografia: ""
asistencia_de_direccion: ""
docente: ""
direccion: "Damián Alexis Moroni"
fotos:
  - src: "/img/obras/2010-barro/2010-barro-01.jpg"
    alt: "Barro, 2010"
    orientacion: vertical
  - src: "/img/obras/2010-barro/2010-barro-02.jpg"
    alt: "Barro, 2010"
    orientacion: apaisada
  - src: "/img/obras/2010-barro/2010-barro-03.jpg"
    alt: "Barro, 2010"
    orientacion: apaisada
  - src: "/img/obras/2010-barro/2010-barro-04.jpg"
    alt: "Barro, 2010"
    orientacion: apaisada
tipo: "Obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---


