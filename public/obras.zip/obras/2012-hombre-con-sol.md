---
title: "Hombre con sol"
anio: 2012
temporadas: []
genero: ["Teatro"]
autor: "Luis Sarlinga"
elenco:
  - "Carla Pollacchi"
  - "Guillermo Tassara"
vestuario: "María Fernanda Bohigues"
iluminacion: "Alfonsina Stivelman"
musica: "Eduardo Akel, Jeremías Aufranc, Ana González Penabad"
sonido: "Leonardo Di Salvo"
direccion_de_arte: ""
escenografia: "María Fernanda Bohigues"
fotografia: "Fernanda Bohigues, Óscar Cabezas, Miur Nagur, Stella Maris Santiago"
asistencia_de_direccion: "María Clara Chardín"
docente: ""
direccion: "Celina González del Solar"
fotos: []
tipo: "Obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---

Un *Hombre con sol* es atravesado por la duda existencial, ¿dios es un vampiro? ¿Cuál es la verdadera tempestad que lo habita? ¿Qué de su pequeño dolor no ha podido enfrentar? Cinco momentos, música, proyecciones, rock, actividad urbana entrelazan la dinámica del ir y venir, estar y ausentarse.
