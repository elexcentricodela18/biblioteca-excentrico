---
title: "Manuela Rosas"
anio: 2021
temporadas: []
genero: ["Teatro"]
autor: "Cristina Banegas"
elenco: ["Cristina Banegas"]
vestuario: ""
iluminacion: ""
musica: ""
sonido: ""
direccion_de_arte: ""
escenografia: ""
fotografia: ""
asistencia_de_direccion: ""
docente: ""
direccion: "Cristina Banegas"
fotos: []
video_url: ""
tipo: "obra"
draft: false
destacada: true
---

Una exploración sobre la figura de Manuela Rosas, hija del Restaurador, en el cruce entre la historia argentina, el poder y la memoria.
