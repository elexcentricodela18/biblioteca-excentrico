---
title: "La ciencia es un colador"
anio: 2024
temporadas: []
genero:
  - "Teatro"
autor: "Maria Belen Perlotti, Lucia Saavedra"
elenco:
  - "Maria Belen Perlotti"
  - "Lucia Saavedra"
vestuario: ""
iluminacion: "Paula Enz"
musica: ""
sonido: "Jimena Saavedra"
direccion_de_arte: ""
escenografia: ""
fotografia: ""
asistencia_de_direccion: "Jimena Saavedra"
docente: ""
direccion: "Paula Enz"
fotos: []
tipo: "obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---

El famoso psicoanalista Sigmund Freud descubre una nueva teoría sobre los sueños, pero no puede corroborarla solo. Para eso, llama a su amigo y colega Josef Breuer, especialista en estudios de neuronas. Juntos, atravesarán el maravilloso mundo de lo onírico, no sin antes navegar torpemente por la incertidumbre de ser ellos mismos. Entre hipnosis, psicodrama y hechos confusos con artefactos ultrasofisticados, estos dos personajes estarán más lejos de la ciencia y más cerca de la locura.
