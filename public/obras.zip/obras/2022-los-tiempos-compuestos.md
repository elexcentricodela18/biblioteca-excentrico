---
title: "Los Tiempos Compuestos"
anio: 2022
temporadas: []
genero: ["Teatro"]
autor: ""
elenco:
  - "Mercedes Aranda"
  - "Mariela Barcos"
  - "José Antonio Bolumburu"
  - "Ceci Cavallero"
  - "Pablo Cusenzaz"
  - "Lucrecia Gratas"
  - "Rosa Ortiz Pereyra"
  - "Ariel Patlayan"
  - "Pablo Sanchez"
vestuario: "Tona Passarelli"
iluminacion: "Samir Carrillo"
musica: ""
sonido: "Pablo Sanchez"
direccion_de_arte: ""
escenografia: "Guillermo Mariscal"
fotografia: "Victoria De Feo"
asistencia_de_direccion: "Tona Passarelli"
docente: ""
direccion: "Guillermo Mariscal"
tipo: "Obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---

En esta comedia oscura, una alumna intenta escapar de una clase sobre los tiempos verbales del español, que se ha transformado en un loop frenético de discusiones, epifanías, muertes y resurrecciones. La llegada de una estudiante de intercambio altera este ciclo irreversible de acontecimientos, dejando entrever las grietas de una tragedia que todos parecían haber olvidado.
