---
title: "La oveja abandonada"
anio: 2012
temporadas: []
genero: ["Teatro"]
autor: ""
elenco:
  - "Alejandro Alvarez"
  - "Fernanda Bercovich"
  - "Rodrigo Martínez Eguizábal"
  - "Fernanda Pérez Bodria"
vestuario: "Ana Florencia Blejer"
iluminacion: "Fernanda Balcells"
musica: "Natalia Sordi"
sonido: ""
direccion_de_arte: ""
escenografia: "Fernando Lancellotti"
fotografia: "Constanza Niscovolos, Juan Risso"
asistencia_de_direccion: "Ana Florencia Blejer"
docente: ""
direccion: "Agustín Rittano"
fotos: []
tipo: "Obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---

Un pueblo encerrado en sí mismo, en su eterna chismografía y su trama de deseos frustrados.
