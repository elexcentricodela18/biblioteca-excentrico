---
title: "La jaqueca"
anio: 2003
temporadas: []
genero: ["Teatro"]
autor: ""
elenco:
  - "Miguel Forza de Paul"
  - "Ana Garibaldi"
  - "Cecilia Peluffo"
vestuario: ""
iluminacion: "Gabriel Caputo"
musica: ""
sonido: ""
direccion_de_arte: ""
escenografia: "Gabriel Caputo"
fotografia: ""
asistencia_de_direccion: "Hernán Cassullo"
docente: ""
direccion: "Cristian Drut"
fotos: []
tipo: "Obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---

*La jaqueca* es una obra sobre arquetipos. Relaciones primarias y esenciales.
Una madre enferma al cuidado de sus dos hijos.

En *La jaqueca*, la metáfora es inmediata. Todo es reconocible. Durante el transcurso ya no sabremos quién cuida a quién. Solo veremos seres tratando de prolongar lo más posible la tregua con el mundo.
