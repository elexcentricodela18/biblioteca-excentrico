---
title: "Cisneros. Una Tragedia Argentina"
anio: 2019
temporadas: []
genero: ["Teatro"]
autor: ""
elenco:
  - "Mauricio González"
  - "Maggie Helou"
  - "Leonardo Odierna"
  - "Mario Petrosini"
  - "Lorena Szekely"
  - "Anabella Valencia"
vestuario: "Jorgelina Herrero Pons, Titi Suárez"
iluminacion: "Eduardo Safigueroa"
musica: "Damian Ferraro"
sonido: "Damian Ferraro"
direccion_de_arte: ""
escenografia: "Jorgelina Herrero Pons"
fotografia: "Gabriel Reig"
asistencia_de_direccion: "Keila Reynoso"
docente: ""
direccion: "Martin Ortiz" 
tipo: "Obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---

*Cisneros. Una tragedia argentina* es una ficción sobre nuestro pasado que habla sobre nuestro presente.