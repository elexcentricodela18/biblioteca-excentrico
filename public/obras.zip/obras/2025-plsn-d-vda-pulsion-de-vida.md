---
title: "PLSN-d-VDA Pulsión de vida"
anio: 2025
temporadas: []
genero:
  - "Teatro"
autor: ""
elenco:
  - "Florencia Cataldi"
  - "Gabriel Falci"
  - "Agustina Ojeda"
  - "Martín Portillo"
vestuario: ""
iluminacion: ""
musica: "Matthew Herbert, Caroline Shaw"
sonido: ""
direccion_de_arte: ""
escenografia: ""
fotografia: "Soledad Torres Agüero"
asistencia_de_direccion: "Nikos Paschidis"
docente: ""
direccion: "Silvia Inés Brunelli"
fotos: 
  - src: "/img/obras/2025-plsn-d-vda-pulsion-de-vida/2025-plsn-d-vda-pulsion-de-vida-01.jpg"
    alt: "PLSN-d-VDA Pulsión de vida, 2025"
    orientacion: cuadrada
tipo: "obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---

Movimiento y Color
Un trabajo en proceso inspirado en la obra de Martín Reyna

Una obra donde color, cuerpo y movimiento se funden creando atmósferas visuales en las que cuatro intérpretes se sumergen y comparten experiencias comunes a cualquier persona: tomar decisiones que se viven como saltos al vacío; preguntarse por el sentido de la vida con sus contradicciones y conflictos.
Pero también la vida se expresa como potencia de danza y color donde las materialidades se disuelven, los cuerpos pierden sus bordes y se desintegran generando otra corporalidad que desorienta al que mira, de pronto volúmenes de rojo se mueven y la piel encarna líneas que se transforman en otra cosa.
