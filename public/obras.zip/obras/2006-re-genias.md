---
title: "Re genias"
anio: 2006
temporadas: []
genero: ["Teatro"]
autor: ""
elenco:
  - "Carla Crespo"
  - "Tatiana Saphir"
vestuario: "Gabriela A. Fernández"
iluminacion: "Matías Sendón"
musica: "Santiago Blaum, Rosario Bléfari, Emmanuel Horvilleur"
sonido: ""
direccion_de_arte: ""
escenografia: "Javier Drolas"
fotografia: "Nicolás Levín"
asistencia_de_direccion: ""
docente: ""
direccion: "Verónica Schneck"
fotos:
  - src: "/img/obras/2006-re-genias/2006-re-genias-01.jpg"
    alt: "Re genias, 2006"
    orientacion: apaisada
tipo: "Obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---

El espectáculo es un montaje escénico de material autobiográfico (diarios íntimos escritos entre los 10 y 21 años) y las asociaciones visuales, físicas, formales y escénicas que (nos) provocan esos textos en su re-lectura.
