---
title: "Resplandece sangre"
anio: 2008
temporadas: []
genero: ["Teatro"]
autor: "Rhea Volij"
elenco:
  - "Rhea Volij"
vestuario: "Líbera Woszezenczuk"
iluminacion: "Eduardo Safigueroa"
musica: "Claudio Peña"
sonido: ""
direccion_de_arte: ""
escenografia: "Carlos Coccia"
fotografia: ""
asistencia_de_direccion: "Isabel Pinczinger, Alfrida Podlischevsky"
docente: ""
direccion: ""
fotos: []
tipo: "Danza"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---

Inspirada en *Rey Lear* (de William Shakespeare), aborda desde la danza butoh las resonancias y fugas que surgieron en la bailarina y coreógrafa Rhea Volij a partir de sumergirse en los personajes de Lear y Cordelia.

*Resplandece sangre* es el despliegue de dos historias que se entrecruzan. Tejidos ancestrales, castillos y familias desintegrándose. La locura lúcida, devenir de dos personajes que en la tensión de sus diferencias se asemejan a medida que mudan de piel, camino a la intemperie.
