---
title: "La muerte del príncipe"
anio: 2003
temporadas: []
genero: ["Teatro"]
autor: "Fernando Pessoa"
elenco:
  - "Pablo Messiez"
  - "Lucía Tebaldi"
vestuario: "Yasmín Tuma"
iluminacion: "Gonzalo Córdova"
musica: ""
sonido: "Fabián Dellamonica"
direccion_de_arte: ""
escenografia: ""
fotografia: ""
asistencia_de_direccion: "Martín Tufró"
docente: ""
direccion: "Adolfo Agopian"
fotos: []
tipo: "Obra"
draft: false
destacada: false
corregida: true
etiqueta: Obra
---

Las contradicciones de un individuo enfrentado a la toma de una decisión, la problemática de un hombre que se instala al borde del vacío y la desesperación ante el acecho de la inacción son los temas fundamentales en torno a los que reflexiona la puesta.
